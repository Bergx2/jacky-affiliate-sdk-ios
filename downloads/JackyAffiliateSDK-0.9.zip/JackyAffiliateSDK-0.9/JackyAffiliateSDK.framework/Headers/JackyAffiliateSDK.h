//
//  Created by Daniel Rinser on 24.04.14.
//  Copyright (c) 2014 Jacky Media. All rights reserved.
//
// The software is provided "as-is", without warranty of any kind, express or implied,
// including but not limited to the warranties of merchantability, fitness for a particular
// purpose and non-infringement. In no event shall the authors or copyright holders be liable
// for any claim, damages or other liability, whether in an action of contract, tort or
// otherwise, arising from, out of or in connection with the software or the use or other
// dealings in the software.
//

#import <Foundation/Foundation.h>

#import <JackyAffiliateSDK/JKYAffiliateManager.h>
#import <JackyAffiliateSDK/JKYInterstitialAppearance.h>
